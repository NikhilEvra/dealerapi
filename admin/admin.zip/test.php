<?php
$cars = array("Volvo", "BMW", "Toyota");
echo $cars[0],$cars[1];
echo json_encode($cars[1],JSON_PRETTY_PRINT)
?>