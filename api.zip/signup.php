<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
// $entityBody = file_get_contents('php://input');

 $con = mysqli_connect("localhost","root","","ionic");
 $q = "SELECT * FROM `user_master`";
$query = mysqli_query($con,$q);
while($row=mysqli_fetch_array($query)){
    $id = $row['id'];

}
$u_id = $id + '1';
$uu_id = "E00" . $u_id;

// echo json_encode($_REQ  
$response= array();
// return json_encode($response);




if($con){ 
    $sql = "INSERT INTO `user_master`(`id`, `u_id`, `name`, `email`, `password`, `phone`) VALUES ('Null','$uu_id','".$_POST['name']."','".$_POST['email']."','".$_POST['password']."','".$_POST['phone']."')";
    $result = mysqli_query($con,$sql);
    if($result){
        echo json_encode(['status'=>true,'message'=>'Success!']);
    }else{
        echo json_encode(['status'=>false,'message'=>'Something Went Wrong!']);
    }
}

?>