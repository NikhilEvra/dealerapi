<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
// $entityBody = file_get_contents('php://input');

 $con = mysqli_connect("localhost","root","","ionic");
// echo json_encode($_REQUEST);
$response= array();
// return json_encode($response);
 $img = $_FILES['file'],['name'];
$_FILES['file'],['tmp_name'];
move_uploaded_file($_FILES['file']['tmp_name'], "$_FILES['file'],['tmp_name'];");
    
if($con){ 
    $sql = "INSERT INTO `user_master`(`name`) VALUES ('$_FILES['file'],['tmp_name'];')";
    $result = mysqli_query($con,$sql);
    if($result){
        echo json_encode(['status'=>true,'message'=>'Success!']);
    }else{
        echo json_encode(['status'=>false,'message'=>'Something Went Wrong!']);
    }
}

?>