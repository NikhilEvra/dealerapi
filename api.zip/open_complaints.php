<?php
 header('Access-Control-Allow-Origin: *');  
$con = mysqli_connect("localhost","root", "","ionic");
$response = array();
if($con){
    $sql = "select * from complaints ";
    $result = mysqli_query($con,$sql);
    if($result){
        $x = 0;
        while($row = mysqli_fetch_assoc($result)) {
            $response [$x]['id'] = $row['id'];
            $response [$x]['name'] = $row['name'];
            $response [$x]['location'] = $row['location'];
            $response [$x]['designation'] = $row['designation'];
            $response [$x]['filename'] = $row['filename'];
            $response [$x]['topic'] = $row['topic'];
            $response [$x]['status'] = $row['status'];
            $x++;
            
        }
        echo json_encode($response,JSON_PRETTY_PRINT);
    }
}else{
    echo "error connecting database";
}

?>