<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
// $entityBody = file_get_contents('php://input');

 $con = mysqli_connect("localhost","root","","ionic");
// echo json_encode($_REQUEST);
$response= array();
// return json_encode($response);

if($con){ 
    $sql = "INSERT INTO `complaints`(`id`, `name`, `location`, `designation`, `topic`, `remark`, `filename`, `status`) VALUES ('null','".$_POST['name']."','".$_POST['location']."','".$_POST['designation']."','".$_POST['topic']."','".$_POST['remark']."','".$_POST['filename']."','Open')";
    $result = mysqli_query($con,$sql);
    if($result){
        echo json_encode(['status'=>true,'message'=>'Success!']);
    }else{
        echo json_encode(['status'=>false,'message'=>'Something Went Wrong!']);
    }
}

?>