<?php
//  header('Access-Control-Allow-Origin: *');  
// $con = mysqli_connect("localhost","root", "","ionic");
// $response = array();
// if($con){
//     $sql = "select * from user_master";
//     $result = mysqli_query($con,$sql);
//     if($result){
//         $x = 0;
//         while($row = mysqli_fetch_assoc($result)) {
//             $response [$x]['id'] = $row['id'];
//             $response [$x]['name'] = $row['name'];
//             $response [$x]['password'] = $row['password'];
//             $x++;
            
//         }
//         echo json_encode($response,JSON_PRETTY_PRINT);
//     }
// }else{
//     echo "error connecting database";
// }


$con = mysqli_connect("localhost","root","","ionic");
// echo json_encode($_REQ  

// return json_encode($response);


$q = "SELECT * FROM `user_master`";
$query = mysqli_query($con,$q);
while($row=mysqli_fetch_array($query)){
    $id = $row['id'];

}
$u_id = $id + '1';
$uu_id = "E00" . $u_id;
echo $uu_id;

?>