<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
// $entityBody = file_get_contents('php://input');

 $con = mysqli_connect("localhost","root","","ionic");
// echo json_encode($_REQUEST);
$response= array();
// return json_encode($response);

if($con){ 
    $sql = "INSERT INTO `customer_sale_master`(`id`, `dealer_id`, `c_name`, `c_mobile`, `location`, `model_name`, `chassis_no`, `amount`) VALUES ('null','".$_POST['name']."','".$_POST['c_name']."','".$_POST['c_mobile']."','".$_POST['location']."','".$_POST['model_name']."','".$_POST['chassis']."','".$_POST['amount']."')";
    $result = mysqli_query($con,$sql);
    if($result){
        echo json_encode(['status'=>true,'message'=>'Success!']);
    }else{
        echo json_encode(['status'=>false,'message'=>'Something Went Wrong!']);
    }
}

?>